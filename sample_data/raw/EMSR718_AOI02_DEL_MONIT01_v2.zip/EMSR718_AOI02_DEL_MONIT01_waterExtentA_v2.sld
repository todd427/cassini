<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:se="http://www.opengis.net/se" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd" version="1.1.0" xmlns:ogc="http://www.opengis.net/ogc">
  <NamedLayer>
    <se:Name>EMSR718_AOI02_DEL_MONIT01_waterExtentA_v2</se:Name>
    <UserStyle>
      <se:Name>EMSR718_AOI02_DEL_MONIT01_waterExtentA_v2</se:Name>
      <se:FeatureTypeStyle>
	  
        <se:Rule>
          <se:Name>Water Extent</se:Name>
          <se:Description>
            <se:Title>Water Extent</se:Title>
          </se:Description>
          <ogc:Filter xmlns:ogc="http://www.opengis.net/ogc">
            <ogc:PropertyIsEqualTo>
			  <ogc:PropertyName>obj_desc</ogc:PropertyName>
             <ogc:Literal>Water Extent</ogc:Literal>
            </ogc:PropertyIsEqualTo>
          </ogc:Filter>
          <se:PolygonSymbolizer>
            <se:Fill>
              <se:SvgParameter name="fill">#4695E3</se:SvgParameter>
            </se:Fill>
          </se:PolygonSymbolizer>
        </se:Rule>
		
		</se:FeatureTypeStyle>
	
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>
